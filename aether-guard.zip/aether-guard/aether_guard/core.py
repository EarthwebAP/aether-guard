"""Core guard implementation."""

import asyncio
import functools
import logging
import random
import time
from typing import Any, Callable, Optional, TypeVar, Union

from .config import GuardConfig
from .exceptions import GuardRetryException, GuardTimeoutException

logger = logging.getLogger(__name__)
T = TypeVar("T")


class CircuitBreaker:
    """Simple circuit breaker for fault tolerance."""

    def __init__(self, threshold: int = 5, reset_timeout: float = 60.0):
        self.threshold = threshold
        self.reset_timeout = reset_timeout
        self.failures = 0
        self.last_failure_time = 0
        self.is_open = False

    def record_success(self):
        """Record successful operation."""
        self.failures = 0
        self.is_open = False

    def record_failure(self):
        """Record failed operation."""
        self.failures += 1
        self.last_failure_time = time.time()
        if self.failures >= self.threshold:
            self.is_open = True

    def can_execute(self) -> bool:
        """Check if operation can execute."""
        if not self.is_open:
            return True

        # Try to reset if timeout elapsed
        elapsed = time.time() - self.last_failure_time
        if elapsed >= self.reset_timeout:
            self.is_open = False
            self.failures = 0
            return True

        return False


_circuit_breaker = CircuitBreaker()


def configure(config: GuardConfig) -> None:
    """Configure global guard settings."""
    GuardConfig.set_default(config)
    _circuit_breaker.threshold = config.circuit_breaker_threshold
    _circuit_breaker.reset_timeout = config.circuit_breaker_reset

    if config.enable_logging:
        logging.basicConfig(level=config.log_level)


def guard(
    timeout: Optional[float] = None,
    retries: Optional[int] = None,
    retry_backoff: Optional[float] = None,
    max_workers: Optional[int] = None,
) -> Callable[[Callable[..., T]], Callable[..., T]]:
    """
    Decorator that adds reliability to any function.

    Usage:
        @guard(timeout=30, retries=3)
        def my_langchain_pipeline():
            return chain.run(...)

    Args:
        timeout: Timeout in seconds
        retries: Number of retries
        retry_backoff: Backoff multiplier
        max_workers: Max concurrent operations

    Returns:
        Decorated function with reliability
    """

    def decorator(func: Callable[..., T]) -> Callable[..., T]:
        config = GuardConfig.get_default()

        # Use provided params or fall back to config
        actual_timeout = timeout if timeout is not None else config.timeout
        actual_retries = retries if retries is not None else config.retries
        actual_backoff = retry_backoff if retry_backoff is not None else config.retry_backoff

        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> T:
            # Check circuit breaker
            if not _circuit_breaker.can_execute():
                raise GuardRetryException(
                    actual_retries,
                    Exception("Circuit breaker is open - backend temporarily unavailable"),
                )

            last_error: Optional[Exception] = None

            for attempt in range(actual_retries + 1):
                try:
                    # Execute with timeout
                    return _execute_with_timeout(func, actual_timeout, args, kwargs)

                except (GuardTimeoutException, GuardRetryException) as e:
                    last_error = e
                    if attempt < actual_retries:
                        # Calculate backoff delay
                        delay = _calculate_backoff(attempt, actual_backoff, config.retry_jitter)
                        logger.warning(
                            f"Attempt {attempt + 1}/{actual_retries + 1} failed, "
                            f"retrying in {delay:.2f}s: {e.message}"
                        )
                        time.sleep(delay)
                    else:
                        _circuit_breaker.record_failure()

                except Exception as e:
                    last_error = e
                    if attempt < actual_retries:
                        delay = _calculate_backoff(attempt, actual_backoff, config.retry_jitter)
                        logger.warning(
                            f"Attempt {attempt + 1}/{actual_retries + 1} failed, "
                            f"retrying in {delay:.2f}s: {str(e)}"
                        )
                        time.sleep(delay)
                    else:
                        _circuit_breaker.record_failure()

            # All retries exhausted
            _circuit_breaker.record_failure()
            raise GuardRetryException(actual_retries, last_error or Exception("Unknown error"))

        # Also support async
        if asyncio.iscoroutinefunction(func):

            @functools.wraps(func)
            async def async_wrapper(*args: Any, **kwargs: Any) -> T:
                config = GuardConfig.get_default()
                actual_timeout = timeout if timeout is not None else config.timeout
                actual_retries = retries if retries is not None else config.retries
                actual_backoff = retry_backoff if retry_backoff is not None else config.retry_backoff

                if not _circuit_breaker.can_execute():
                    raise GuardRetryException(
                        actual_retries,
                        Exception("Circuit breaker is open"),
                    )

                last_error: Optional[Exception] = None

                for attempt in range(actual_retries + 1):
                    try:
                        return await asyncio.wait_for(func(*args, **kwargs), timeout=actual_timeout)

                    except asyncio.TimeoutError as e:
                        last_error = GuardTimeoutException(actual_timeout, attempt)
                        if attempt < actual_retries:
                            delay = _calculate_backoff(attempt, actual_backoff, config.retry_jitter)
                            logger.warning(f"Async timeout, retrying in {delay:.2f}s")
                            await asyncio.sleep(delay)
                        else:
                            _circuit_breaker.record_failure()

                    except Exception as e:
                        last_error = e
                        if attempt < actual_retries:
                            delay = _calculate_backoff(attempt, actual_backoff, config.retry_jitter)
                            logger.warning(f"Async error, retrying in {delay:.2f}s: {str(e)}")
                            await asyncio.sleep(delay)
                        else:
                            _circuit_breaker.record_failure()

                _circuit_breaker.record_failure()
                raise GuardRetryException(actual_retries, last_error or Exception("Unknown error"))

            return async_wrapper  # type: ignore

        return wrapper  # type: ignore

    return decorator


def _execute_with_timeout(
    func: Callable[..., T], timeout: float, args: tuple, kwargs: dict
) -> T:
    """Execute function with timeout protection."""
    try:
        return func(*args, **kwargs)
    except TimeoutError:
        raise GuardTimeoutException(timeout)


def _calculate_backoff(attempt: int, backoff_multiplier: float, use_jitter: bool) -> float:
    """Calculate exponential backoff delay."""
    delay = (backoff_multiplier ** attempt)

    if use_jitter:
        # Add random jitter (±10%)
        jitter = delay * 0.1 * random.random()
        delay += jitter if random.random() > 0.5 else -jitter
        delay = max(0.1, delay)  # Ensure minimum delay

    return delay
