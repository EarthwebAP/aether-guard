"""Configuration for aether-guard."""

from dataclasses import dataclass, field
from typing import Optional


@dataclass
class GuardConfig:
    """Configuration for guard behavior."""

    # Timeout settings
    timeout: float = 30.0
    """Timeout in seconds for individual operations."""

    # Retry settings
    retries: int = 3
    """Maximum number of retries on failure."""

    retry_backoff: float = 1.0
    """Backoff multiplier for exponential retry delays (1.0 = linear)."""

    retry_jitter: bool = True
    """Add randomness to retry delays to prevent thundering herd."""

    # Concurrency settings
    max_workers: int = 100
    """Maximum concurrent operations."""

    # Backend settings
    backend_url: str = "http://localhost:8000"
    """URL of aether-distiller backend."""

    backend_timeout: float = 60.0
    """Timeout for backend connection."""

    # Circuit breaker settings
    circuit_breaker_threshold: int = 5
    """Failures before circuit breaker opens."""

    circuit_breaker_reset: float = 60.0
    """Seconds to wait before trying to reset circuit breaker."""

    # Monitoring settings
    enable_metrics: bool = True
    """Enable metrics collection."""

    enable_logging: bool = True
    """Enable debug logging."""

    log_level: str = "INFO"
    """Log level (DEBUG, INFO, WARNING, ERROR)."""

    # Global config (overridable)
    _instance: Optional["GuardConfig"] = field(default=None, init=False, repr=False)

    @classmethod
    def get_default(cls) -> "GuardConfig":
        """Get or create default config instance."""
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    @classmethod
    def set_default(cls, config: "GuardConfig") -> None:
        """Set default config instance."""
        cls._instance = config

    def copy(self, **kwargs) -> "GuardConfig":
        """Create a copy with optional overrides."""
        import dataclasses

        values = {f.name: getattr(self, f.name) for f in dataclasses.fields(self)}
        values.update(kwargs)
        return GuardConfig(**{k: v for k, v in values.items() if k != "_instance"})
