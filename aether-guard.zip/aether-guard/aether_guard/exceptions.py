"""aether-guard exception hierarchy."""


class GuardException(Exception):
    """Base exception for all aether-guard errors."""

    def __init__(self, message: str, retry_count: int = 0):
        self.message = message
        self.retry_count = retry_count
        super().__init__(self.message)


class GuardTimeoutException(GuardException):
    """Raised when operation exceeds timeout."""

    def __init__(self, timeout_seconds: float, retry_count: int = 0):
        message = f"Operation timed out after {timeout_seconds} seconds"
        super().__init__(message, retry_count)
        self.timeout_seconds = timeout_seconds


class GuardRetryException(GuardException):
    """Raised when all retries are exhausted."""

    def __init__(self, max_retries: int, last_error: Exception):
        message = f"Operation failed after {max_retries} retries: {str(last_error)}"
        super().__init__(message, max_retries)
        self.max_retries = max_retries
        self.last_error = last_error


class GuardConnectionException(GuardException):
    """Raised when connection to backend fails."""

    def __init__(self, reason: str):
        message = f"Failed to connect to aether-distiller backend: {reason}"
        super().__init__(message)
        self.reason = reason
