"""
aether-guard: Bulletproof Reliability for AI Agents

Add 3 lines of code, get 99.99% uptime.

Example:
    from aether_guard import guard

    @guard(timeout=30, retries=3)
    def my_langchain_pipeline():
        return chain.run("Generate report...")
"""

from .core import guard, configure, GuardConfig
from .decorators import async_guard, sync_guard
from .exceptions import GuardException, GuardTimeoutException, GuardRetryException

__version__ = "0.1.0"
__all__ = [
    "guard",
    "async_guard",
    "sync_guard",
    "configure",
    "GuardConfig",
    "GuardException",
    "GuardTimeoutException",
    "GuardRetryException",
]
