"""Specialized decorators for async/sync patterns."""

import functools
from typing import Any, Callable, Optional, TypeVar

from .core import guard

T = TypeVar("T")


def sync_guard(
    timeout: float = 30,
    retries: int = 3,
    retry_backoff: float = 1.0,
) -> Callable[[Callable[..., T]], Callable[..., T]]:
    """
    Decorator for synchronous functions.

    Usage:
        @sync_guard(timeout=30, retries=3)
        def my_sync_function():
            return do_work()
    """
    return guard(timeout=timeout, retries=retries, retry_backoff=retry_backoff)


def async_guard(
    timeout: float = 30,
    retries: int = 3,
    retry_backoff: float = 1.0,
) -> Callable[[Callable[..., T]], Callable[..., T]]:
    """
    Decorator for async functions.

    Usage:
        @async_guard(timeout=30, retries=3)
        async def my_async_function():
            return await do_work()
    """
    return guard(timeout=timeout, retries=retries, retry_backoff=retry_backoff)
