#!/usr/bin/env python3
"""
Example: Basic aether-guard Usage

Demonstrates the simplest way to add reliability to any function.
"""

from aether_guard import guard, configure, GuardConfig


# Example 1: Simplest possible usage
@guard()
def unreliable_function():
    """A function that might fail."""
    import random

    if random.random() < 0.3:  # 30% failure rate
        raise Exception("Random failure")

    return "Success!"


# Example 2: With custom timeout
@guard(timeout=10)
def slow_function():
    """Function that might take too long."""
    import time

    time.sleep(2)
    return "Completed in time!"


# Example 3: With custom retries
@guard(retries=5)
def flaky_api_call():
    """Function that fails frequently but recovers."""
    import random

    if random.random() < 0.5:  # 50% failure rate
        raise Exception("API temporarily unavailable")

    return {"status": "ok"}


# Example 4: All options specified
@guard(timeout=30, retries=3, retry_backoff=2.0)
def production_grade_function():
    """Production-ready function with full reliability config."""
    return "This is bulletproof"


# Example 5: Global configuration
def setup_global_config():
    """Configure defaults for all @guard() decorators."""
    config = GuardConfig(
        timeout=30,
        retries=3,
        retry_backoff=1.5,
        circuit_breaker_threshold=5,
        circuit_breaker_reset=60,
        enable_logging=True,
    )
    configure(config)


# Example 6: Exception handling
def handle_errors():
    """Show how to handle aether-guard exceptions."""
    from aether_guard import GuardRetryException, GuardTimeoutException

    @guard(timeout=5, retries=2)
    def might_fail():
        raise Exception("Always fails")

    try:
        might_fail()
    except GuardRetryException as e:
        print(f"Failed after {e.max_retries} retries: {e.last_error}")
    except GuardTimeoutException as e:
        print(f"Timed out after {e.timeout_seconds}s")


# Example 7: Async function
import asyncio


@guard(timeout=10, retries=3)
async def async_function():
    """Async functions also get reliability."""
    await asyncio.sleep(1)
    return "Async completed"


def main():
    """Run all examples."""
    print("=" * 50)
    print("aether-guard Basic Usage Examples")
    print("=" * 50)
    print()

    # Example 1
    print("Example 1: Unreliable Function (30% failure rate)")
    for i in range(5):
        try:
            result = unreliable_function()
            print(f"  Attempt {i + 1}: {result}")
        except Exception as e:
            print(f"  Attempt {i + 1}: Failed - {e}")
    print()

    # Example 2
    print("Example 2: Slow Function (with timeout)")
    try:
        result = slow_function()
        print(f"  Result: {result}")
    except Exception as e:
        print(f"  Error: {e}")
    print()

    # Example 3
    print("Example 3: Flaky API Call")
    try:
        result = flaky_api_call()
        print(f"  Result: {result}")
    except Exception as e:
        print(f"  Error: {e}")
    print()

    # Example 4
    print("Example 4: Production Grade Function")
    try:
        result = production_grade_function()
        print(f"  Result: {result}")
    except Exception as e:
        print(f"  Error: {e}")
    print()

    # Example 5
    print("Example 5: Global Configuration")
    setup_global_config()
    print("  Configuration set for all @guard() decorators")
    print()

    # Example 6
    print("Example 6: Exception Handling")
    handle_errors()
    print()

    # Example 7
    print("Example 7: Async Function")
    try:
        result = asyncio.run(async_function())
        print(f"  Result: {result}")
    except Exception as e:
        print(f"  Error: {e}")
    print()

    print("=" * 50)
    print("✅ All examples completed!")
    print("=" * 50)


if __name__ == "__main__":
    main()
