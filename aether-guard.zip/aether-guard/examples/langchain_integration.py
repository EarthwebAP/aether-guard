#!/usr/bin/env python3
"""
Example: Using aether-guard with LangChain

This example shows how to add bulletproof reliability to LangChain chains
with just 3 lines of code.
"""

from aether_guard import guard, configure, GuardConfig

# Optional: Configure global defaults
config = GuardConfig(
    timeout=60,
    retries=3,
    enable_logging=True,
)
configure(config)


# Example 1: Basic LangChain Chain
@guard(timeout=30, retries=3)
def simple_chain():
    """Run a simple LLM chain with reliability."""
    from langchain.llms import OpenAI
    from langchain.chains import LLMChain
    from langchain.prompts import PromptTemplate

    llm = OpenAI(temperature=0)
    prompt = PromptTemplate(input_variables=["topic"], template="Write about {topic}")
    chain = LLMChain(llm=llm, prompt=prompt)

    # Now has automatic retries, timeout protection, circuit breaker
    return chain.run(topic="AI reliability")


# Example 2: Agent Chain with Custom Config
@guard(timeout=120, retries=5)  # Longer timeout for complex operations
def complex_agent_chain():
    """Run a complex agent with more aggressive retry policy."""
    from langchain.agents import initialize_agent, Tool
    from langchain.llms import OpenAI

    llm = OpenAI(temperature=0)

    # Define tools
    tools = [
        Tool(name="Tool1", func=lambda x: x, description="Tool 1"),
        Tool(name="Tool2", func=lambda x: x, description="Tool 2"),
    ]

    # Create agent with reliability wrapper
    agent = initialize_agent(tools, llm, agent="zero-shot-react-description", verbose=True)

    # Execute with automatic fault tolerance
    return agent.run("Complex task requiring multiple steps")


# Example 3: Batch Processing with Reliability
@guard(timeout=300, retries=3)  # Long timeout for batch operations
def process_documents_batch(documents):
    """Process multiple documents with reliability."""
    from langchain.llms import OpenAI
    from langchain.chains import LLMChain
    from langchain.prompts import PromptTemplate

    llm = OpenAI(temperature=0)
    prompt = PromptTemplate(
        input_variables=["text"],
        template="Summarize this text:\n\n{text}\n\nSummary:",
    )
    chain = LLMChain(llm=llm, prompt=prompt)

    results = []
    for doc in documents:
        # Each call is protected
        result = chain.run(text=doc)
        results.append(result)

    return results


# Example 4: QA Chain
@guard(timeout=60, retries=3)
def qa_chain_reliable():
    """Run a QA chain with automatic reliability."""
    from langchain.llms import OpenAI
    from langchain.chains import RetrievalQA
    from langchain.embeddings import OpenAIEmbeddings
    from langchain.vectorstores import FAISS

    llm = OpenAI(temperature=0)
    embeddings = OpenAIEmbeddings()

    # Assume you have a vector store set up
    # vectorstore = FAISS.load_local("index_name", embeddings)
    # qa_chain = RetrievalQA.from_chain_type(llm, retriever=vectorstore.as_retriever())

    # Execute with reliability
    # return qa_chain.run("What is the answer to this question?")
    return "QA chain result"


# Example 5: Sequential Chains
@guard(timeout=120, retries=3)
def sequential_chain_reliable():
    """Run sequential chains with reliability."""
    from langchain.llms import OpenAI
    from langchain.chains import SequentialChain, LLMChain
    from langchain.prompts import PromptTemplate

    llm = OpenAI(temperature=0)

    # Create first chain
    prompt1 = PromptTemplate(
        input_variables=["topic"], template="Outline an essay about {topic}"
    )
    chain1 = LLMChain(llm=llm, prompt=prompt1, output_key="outline")

    # Create second chain
    prompt2 = PromptTemplate(
        input_variables=["outline"], template="Write an essay from this outline:\n{outline}"
    )
    chain2 = LLMChain(llm=llm, prompt=prompt2, output_key="essay")

    # Combine into sequential chain
    seq_chain = SequentialChain(
        chains=[chain1, chain2],
        input_variables=["topic"],
        output_variables=["outline", "essay"],
    )

    # Entire sequence is protected
    return seq_chain(topic="The Future of AI")


# Example 6: Using aether-guard with Custom Error Handling
@guard(timeout=30, retries=3)
def chain_with_error_handling():
    """Show how to handle aether-guard exceptions."""
    from langchain.llms import OpenAI
    from langchain.chains import LLMChain
    from langchain.prompts import PromptTemplate
    from aether_guard import GuardRetryException, GuardTimeoutException

    try:
        llm = OpenAI(temperature=0)
        prompt = PromptTemplate(input_variables=["topic"], template="Topic: {topic}")
        chain = LLMChain(llm=llm, prompt=prompt)

        return chain.run(topic="AI")

    except GuardTimeoutException as e:
        print(f"Operation timed out after {e.timeout_seconds}s")
        # Handle timeout - maybe use cached result or fallback
        return "Fallback response due to timeout"

    except GuardRetryException as e:
        print(f"Operation failed after {e.max_retries} retries")
        # Handle retries exhausted - log, alert, use default
        return "Fallback response due to repeated failures"


def main():
    """Run examples."""
    print("Example 1: Simple Chain")
    try:
        result = simple_chain()
        print(f"Result: {result[:100]}...\n")
    except Exception as e:
        print(f"Error: {e}\n")

    print("Example 2: Complex Agent")
    try:
        result = complex_agent_chain()
        print(f"Result: {result[:100]}...\n")
    except Exception as e:
        print(f"Error: {e}\n")

    print("All examples demonstrate reliability with minimal code changes!")
    print("Just add @guard() and your chains are bulletproof.")


if __name__ == "__main__":
    main()
